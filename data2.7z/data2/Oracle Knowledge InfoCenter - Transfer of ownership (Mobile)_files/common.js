/**
 * Copyright (c) 2002, 2012 Oracle and/or its affiliates. All rights reserved.
 * Oracle and Java are registered trademarks of Oracle and/or its affiliates. Other names may be trademarks of their respective owners.
 * 
 * This software and related documentation are provided under a license agreement containing restrictions 
 * on use and disclosure and are protected by intellectual property laws. Except as expressly permitted 
 * in your license agreement or allowed by law, you may not use, copy, reproduce, translate, broadcast, modify, 
 * license, transmit, distribute, exhibit, perform, publish or display any part, in any form, or by any means. 
 * Reverse engineering, disassembly, or decompilation of this software, unless required by law for interoperability, is prohibited.
 * 
 * The information contained herein is subject to change without notice and is not warranted to be error-free. If you find any errors, please report them to us in writing.
 * 
 * If this is software or related documentation that is delivered to the U.S. Government or anyone licensing it on behalf of the U.S. Government, the following notice is applicable:
 * 
 * U.S. GOVERNMENT END USERS: Oracle programs, including any operating system, integrated software, 
 * any programs installed on the hardware, and/or documentation, delivered to U.S. Government end users are "commercial computer software" 
 * pursuant to the applicable Federal Acquisition Regulation and agency-specific supplemental regulations. As such, use, duplication, 
 * disclosure, modification, and adaptation of the programs, including any operating system, integrated software, any programs installed 
 * on the hardware, and/or documentation, shall be subject to license terms and license restrictions applicable to the programs. No other rights are granted to the U.S. Government.
 * 
 * This software or hardware is developed for general use in a variety of information management applications. It is 
 * not developed or intended for use in any inherently dangerous applications, including applications that may create a risk of 
 * personal injury. If you use this software or hardware in dangerous applications, then you shall be responsible to take all 
 * appropriate fail- safe, backup, redundancy, and other measures to ensure its safe use. Oracle Corporation and its affiliates 
 * disclaim any liability for any damages caused by use of this software or hardware in dangerous applications.
 * 
 * This software or hardware and documentation may provide access to or information on content, products and services from third parties. 
 * Oracle Corporation and its affiliates are not responsible for and expressly disclaim all warranties of any kind with respect to 
 * third-party content, products, and services. Oracle Corporation and its affiliates will not be responsible for any loss, costs, 
 * or damages incurred due to your access to or use of third-party content, products, or services. 
 * 
 */

/**
 * Browser.js
 *
 * JavaScript object for capturing browser information.
 *
 */

/**
  * Browser Constructor
  */
function Browser()
{
    this.name = window.navigator.appName.toLowerCase();
    this.version = window.navigator.appVersion;
}


/**
  * Check to see if we are using Netscape.
  */
function _Browser_isNetscape()
{
    return (this.name == "netscape")
}


/**
  * Check to see if we are using InternetExplorer.
  */
function _Browser_isIE()
{
    return (this.name == "microsoft internet explorer")
}

/**
  * Get the available display height of the browser window.
  */
function _Browser_getHeight()
{
    if (this.isIE)
        return document.documentElement.clientHeight;
    else
        return window.innerHeight;
}

function _Browser_getWidth()
{
    if (this.isIE)
        return document.documentElement.clientWidth;
    else
        return window.innerWidth;
}


/**
  * Assign Prototype Methods
  */
Browser.prototype.isNetscape    = _Browser_isNetscape;
Browser.prototype.isIE          = _Browser_isIE;
Browser.prototype.getHeight     = _Browser_getHeight;
Browser.prototype.getWidth     = _Browser_getWidth;
/**
 * EventWrapper.js
 *
 * JavaScript object wrapper for browser events.
 *
 * The purpose of this object is to provide a set of browser-independent
 * APIs for accessing browser events in JavaScript.
 *
 */

/**
  * EventWrapper Constructor
  */
function EventWrapper(p_event, p_browser)
{
    // Member variables
    this.event    = p_event;
    this.browser  = p_browser;

    // Key constants
    this.key       = new Object();
    this.key.ENTER = 13;
}


/**
  * Check to see if a specific key was pressed.
  */
function _EventWrapper_isKeyPress(p_keycode)
{
    var keyCode = this.browser.isNetscape() ? this.event.which : this.event.keyCode;

    if (keyCode == p_keycode)
       return true;
    else
       return false;
}

/**
  * Return the DOM element that fired the event.
  */
function _EventWrapper_getElement()
{
    if (this.browser.isIE())
        return this.event.srcElement;
    else if (this.browser.isNetscape())
        return this.event.target;
}

/**
  * Assign Prototype Methods
  */
EventWrapper.prototype.isKeyPress    = _EventWrapper_isKeyPress;
EventWrapper.prototype.getElement    = _EventWrapper_getElement;

function fnToggle(strID, strToggleTo) {
	document.getElementById(strID).style.display = strToggleTo;
	if (strID=="MoreAlerts" && strToggleTo=="block") {
		document.getElementById("showMoreAlerts").style.display = "none";
	} else if (strID=="MoreAlerts" && strToggleTo=="none") {
		document.getElementById("showMoreAlerts").style.display = "block";
	}
}

function OpenTipsWindow(querystring) {
	LeftPosition = (screen.width) ? (screen.width)/10 : 0;
	TopPosition = (screen.height) ? (screen.height)/10 : 0;
	settings = "menubar=no,height=424,width=600,resizable=no,scrollbars=yes"
	hWin = window.open(querystring, "Tips", settings, true);
	hWin.focus();
	if (hWin.opener == null) hWin.opener = self;
}
var qna_browser        = new Browser();
/**
  * Handle a key press release event in the question box.
  */
function handleKeyPress_QuestionBox(p_evt)
{
    var ew = new EventWrapper(p_evt, qna_browser);

    if (ew.isKeyPress(ew.key.ENTER))
    {
        var qBox = ew.getElement();
        qBox.blur();
        qBox.value = qBox.value.replace(/\s+$/,""); // Strip whitespace from end
        document.question_form.Ask.disabled = true;
   		document.question_form.submit();
        return false;
    }
    return true;
}

//change the portlet display as block or none
function display(img, identify, strResourcePath, isSecureRequest, languageDirection) {
    var url1 = strResourcePath+"images/portlet_navigate_open.gif";
    var url2 = strResourcePath+"images/portlet_navigate_closed_ltr.gif";
    if ("rtl" == languageDirection) {
    	url2 = strResourcePath+"images/portlet_navigate_closed_rtl.gif";
    }
    if(typeof(img) == "string"){
        img = document.getElementById(img);
    }
    img.src = url2;
    var obj = document.getElementById(identify);
    if (obj.style.display == "none") {
        obj.style.display = "block";
        img.src = url1;
    } else {
        img.src = url2;
        obj.style.display = "none";
    }
    if (isSecureRequest == "undefined" || isSecureRequest == null) {
    	isSecureRequest = false;
    }
    
    SetCookie(identify, obj.style.display, null, null, null, isSecureRequest);
}

// if no js, keep all portlet open without icon(arrow)
// if with js, setup portlet for adding img into img span
function setupPortlet(spanId, imgId, contentId, status){
	var imgSpan = document.getElementById(spanId);
	if(imgSpan){
		var imgC = document.createElement("img");
		imgC.id = imgId;
		imgSpan.appendChild(imgC);
	}
	
	if(contentId){
		var content = document.getElementById(contentId);
		if(content){
			var defaultStatus = "block";
			if(status){
				defaultStatus = status;
			}
			content.style.display = defaultStatus;
		}
	}
}

//init portlet state, fetch the state from cookie
function initPortlet(img, identify, strResourcePath, languageDirection){
    var url1 = strResourcePath+"images/portlet_navigate_open.gif";
    var url2 = strResourcePath+"images/portlet_navigate_closed_ltr.gif";
    if ("rtl" == languageDirection) {
    	url2 = strResourcePath+"images/portlet_navigate_closed_rtl.gif";
    }
    var status = GetCookie(identify);
    var obj = document.getElementById(identify);
    // if there is no record in cookie, 
    // by default it should display except the default is no display
	if(obj != null) {
		if(!status){
			if(obj.style.display && (obj.style.display=="none")){
				status = "none";
			}else{
				status = "block";
			}
		}
		obj.style.display = status;
	}
	if(status == "block" && document.getElementById(img) != null){
	    document.getElementById(img).src = url1;
	}else{
		document.getElementById(img).src = url2;
	}
}

//these two method are for textarea maxlength
// such as: <textarea maxlength="1000" onkeypress="return imposeMaxLength(this)" onkeyup="isMaxlength(this)"></textarea>
function isMaxlength(obj){	
	var mlen;
	if(obj.getAttribute("maxlength") != null){
		mlen = parseInt(obj.getAttribute("maxlength"));	
	} else if(obj.attributes.maxLength && obj.attributes.maxLength.specified){
		mlen = parseInt(obj.attributes.maxLength.nodeValue);
	} else{
		mlen = 1000;
	}	
	if (obj.getAttribute && obj.value.length>mlen){		
		obj.value=obj.value.substring(0,mlen-1)	
	}
}
	
function imposeMaxLength(obj){  
	var mlen;
	if(obj.getAttribute("maxlength") != null){
		mlen = parseInt(obj.getAttribute("maxlength"));	
	} else if(obj.attributes.maxLength && obj.attributes.maxLength.specified){
		mlen = parseInt(obj.attributes.maxLength.nodeValue);
	} else{
		mlen = 1000;
	}   
	return (obj.value.length <= mlen);
}

String.prototype.trim = function() 
{ 
	return this.replace(/(^\s*)|(\s*$)/g, ""); 
} 

function validateSearchInput(obj) {
	var submitable = true;
	if(obj.question_box_status) {
		if(obj.question_box_status.value == "init") {
			submitable = false;
		}
	}
	if(submitable && obj.question_box.value.trim() != "") {
		return true;
	}

	return false;
}

var IQUtil = {
/* create element by tag type, do not support input */
	create : function(t, o, p){
	   var e = null;
	   if(null != t){
	       e = document.createElement(t);
	       if(p){
	    	   p.appendChild(e);
	       }
	   }
	
	   if(o){
	     for(x in o){
	         try{
	             e[x] = o[x];
	         }catch(ex){}
	     }
	   }
	   return e;
	}
}

function goToPage(href) {
	location.href=href;
}

function getParamValueFromURL(strURL, paramName, defaultValue) {
    var paramValue = null;
	if (strURL != null && strURL != "") {
        var arrParams = strURL.split("&");
	    if (arrParams != null) {
			for (var i = (arrParams.length-1);i > -1;i--) {
	            if (paramValue == null && arrParams[i] != null) {
		            var arrKeyValue = arrParams[i].split("=");
				    if (arrKeyValue != null && arrKeyValue.length > 0 && arrKeyValue[0] == paramName) {
			            if (arrKeyValue.length > 1) {
				            paramValue = arrKeyValue[1];
					    } else {
				            paramValue = defaultValue;
					    }
						break;
				    }
			    }
			}
		}
	}
	
	return paramValue;
}