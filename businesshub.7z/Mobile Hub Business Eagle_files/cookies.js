/**
 * Copyright (c) 2002, 2012 Oracle and/or its affiliates. All rights reserved.
 * Oracle and Java are registered trademarks of Oracle and/or its affiliates. Other names may be trademarks of their respective owners.
 * 
 * This software and related documentation are provided under a license agreement containing restrictions 
 * on use and disclosure and are protected by intellectual property laws. Except as expressly permitted 
 * in your license agreement or allowed by law, you may not use, copy, reproduce, translate, broadcast, modify, 
 * license, transmit, distribute, exhibit, perform, publish or display any part, in any form, or by any means. 
 * Reverse engineering, disassembly, or decompilation of this software, unless required by law for interoperability, is prohibited.
 * 
 * The information contained herein is subject to change without notice and is not warranted to be error-free. If you find any errors, please report them to us in writing.
 * 
 * If this is software or related documentation that is delivered to the U.S. Government or anyone licensing it on behalf of the U.S. Government, the following notice is applicable:
 * 
 * U.S. GOVERNMENT END USERS: Oracle programs, including any operating system, integrated software, 
 * any programs installed on the hardware, and/or documentation, delivered to U.S. Government end users are "commercial computer software" 
 * pursuant to the applicable Federal Acquisition Regulation and agency-specific supplemental regulations. As such, use, duplication, 
 * disclosure, modification, and adaptation of the programs, including any operating system, integrated software, any programs installed 
 * on the hardware, and/or documentation, shall be subject to license terms and license restrictions applicable to the programs. No other rights are granted to the U.S. Government.
 * 
 * This software or hardware is developed for general use in a variety of information management applications. It is 
 * not developed or intended for use in any inherently dangerous applications, including applications that may create a risk of 
 * personal injury. If you use this software or hardware in dangerous applications, then you shall be responsible to take all 
 * appropriate fail- safe, backup, redundancy, and other measures to ensure its safe use. Oracle Corporation and its affiliates 
 * disclaim any liability for any damages caused by use of this software or hardware in dangerous applications.
 * 
 * This software or hardware and documentation may provide access to or information on content, products and services from third parties. 
 * Oracle Corporation and its affiliates are not responsible for and expressly disclaim all warranties of any kind with respect to 
 * third-party content, products, and services. Oracle Corporation and its affiliates will not be responsible for any loss, costs, 
 * or damages incurred due to your access to or use of third-party content, products, or services. 
 * 
 */

// the earliest time point system can get. 
// used when one cookie needs to be deleted.
var expiredate = new Date();
expiredate.setTime(0);

var today = new Date();

/* To get cookie value by cookie name
 * First check if there is such a cookie
 * If exists, get the value by splitting the cookie string by "="
 * ant the second token is the value
*/
function GetCookie (cKey){
    
	var identifier = cKey + "=";
	var cookieArray = document.cookie.split(";");
	var cVal = null;
	for (var i = 0; i < cookieArray.length; i++){
	    cookie = cookieArray[i];
	    // Trim leading spaces for each cookie
	    cookie = cookie.replace(/^\s*/, '');
		if (cookie.indexOf(identifier) == 0){
			if (cookie.split("=").length > 1){
				cVal = unescape(cookie.split("=")[1]);
			}else{
				cVal = "";
			}
			break;
		}
	}
	return cVal;
}

/* To set cookie value
** The expires is Date type
*/
function SetCookie (cKey,cVal,expiresDate,cPath,domainName,isSecure){
	if (cKey){
		var tempCookie = cKey + "=" + escape(cVal);
		if (expiresDate){
			tempCookie += "; expires=" + expiresDate.toGMTString();
		}
		
		if (cPath){
			tempCookie += "; path=" + cPath;
		}
		
		if (domainName){
			tempCookie += "; domain=" + cokieDomain;
		}
		
		if (true == isSecure){
			tempCookie += "; secure";
		}
		
		document.cookie = tempCookie;
	}
}

/* Set the cookie's expired time to an early time point
** to tell the browser this cookie is expired.
** And then the browser will recycle it 
** when it finds this cookie is expired
*/
function DeleteCookie (cKey, domainName, cPath){
	var vVal = GetCookie (cKey);
	if (vVal && vVal!=null){
		SetCookie(cKey,"",expiredate,cPath,domainName);
	}
}